var fs = require('fs-extra');
fs.removeSync('./dist');
